﻿// Default code generation is disabled for model 'C:\Users\AnthonyOToole\Desktop\Semester 3\EntityFrameworkResearch\4.Project Versions\MotoristPenaltyPoints\MotoristPenaltyPoints\Models\MotoristPenaltyPointsModel.edmx'. 
// To enable default code generation, change the value of the 'Code Generation Strategy' designer
// property to an alternate value. This property is available in the Properties Window when the model is
// open in the designer.